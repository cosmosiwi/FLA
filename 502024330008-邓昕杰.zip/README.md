### 通过cmake编译

cmake -B build

### 进入build文件并且执行make

cd build && make
